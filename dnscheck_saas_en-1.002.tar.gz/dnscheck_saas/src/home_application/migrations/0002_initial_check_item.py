# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import json
from django.db import migrations
from settings import CHECK_ITEM_JSON_FILE
from home_application.models import CheckItem


def initial_check_item(apps, schema_editor):
    try:
        CheckItem.objects.all().delete()
        json_data = open(CHECK_ITEM_JSON_FILE)
        check_content_obj = json.load(json_data)
        order = 1
        check_items = []
        for i in check_content_obj:
            check_items.append(CheckItem(
                id=order,
                menu_name=i["menu_name"],
                object_name=i["object_name"],
                name=i["name"],
                cn_name=i["cn_name"],
                compare_way=i["compare_way"],
                compare_value=i["compare_value"],
                description=i["description"]
            ))
            order += 1
        CheckItem.objects.bulk_create(check_items)
        json_data.close()
    except Exception, e:
        print e.message


class Migration(migrations.Migration):
    dependencies = [
        ('home_application', '0001_initial'),
    ]

    operations = [
        migrations.RunPython(initial_check_item),
    ]
