# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('home_application', '0004_logoimg'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='logs',
            name='operated_type',
        ),
        migrations.RemoveField(
            model_name='logs',
            name='when_created',
        ),
        migrations.AddField(
            model_name='logs',
            name='operate_detail',
            field=models.TextField(default=b''),
        ),
        migrations.AddField(
            model_name='logs',
            name='operate_obj',
            field=models.CharField(default=b'', max_length=100),
        ),
        migrations.AddField(
            model_name='logs',
            name='operate_time',
            field=models.CharField(default=b'', max_length=20),
        ),
        migrations.AddField(
            model_name='logs',
            name='operate_type',
            field=models.CharField(default=b'', max_length=50),
        ),
        migrations.AlterField(
            model_name='logs',
            name='operator',
            field=models.CharField(max_length=100),
        ),
    ]
