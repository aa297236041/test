# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='CheckItem',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('menu_name', models.CharField(max_length=100)),
                ('object_name', models.CharField(max_length=100)),
                ('name', models.CharField(max_length=100)),
                ('cn_name', models.CharField(max_length=100)),
                ('compare_way', models.CharField(default=b'', max_length=10, null=True)),
                ('compare_value', models.CharField(default=b'', max_length=100, null=True)),
                ('description', models.TextField(default=b'', null=True)),
                ('is_show', models.BooleanField(default=False)),
            ],
        ),
        migrations.CreateModel(
            name='CheckReport',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('when_created', models.CharField(max_length=100)),
                ('report_info', models.CharField(max_length=200, null=True)),
                ('status', models.CharField(default=b'RUNNING', max_length=100, null=True)),
            ],
        ),
        migrations.CreateModel(
            name='CheckReportDetail',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('server', models.CharField(max_length=100)),
                ('is_success', models.BooleanField(default=True)),
                ('fail_result', models.TextField(default=b'', null=True)),
                ('check_report', models.ForeignKey(to='home_application.CheckReport')),
            ],
        ),
        migrations.CreateModel(
            name='CheckServers',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('ip_address', models.CharField(max_length=50)),
                ('app_id', models.IntegerField()),
                ('app_name', models.CharField(max_length=100)),
                ('source', models.IntegerField()),
                ('when_created', models.CharField(max_length=20)),
                ('created_by', models.CharField(max_length=100)),
                ('modified_by', models.CharField(max_length=100)),
                ('when_modified', models.CharField(max_length=20)),
            ],
        ),
        migrations.CreateModel(
            name='CheckTask',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(default='DNS\u5de1\u68c0', max_length=100)),
                ('first_run_time', models.CharField(max_length=100)),
                ('run_time', models.CharField(max_length=100)),
                ('time_interval', models.IntegerField(default=7)),
                ('keeps', models.IntegerField(default=0)),
                ('script_account', models.CharField(max_length=100)),
                ('is_delete', models.BooleanField(default=False)),
            ],
        ),
        migrations.CreateModel(
            name='InfoDetail',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('value', models.TextField()),
                ('is_warn', models.BooleanField(default=False)),
                ('detail_type', models.CharField(max_length=100)),
                ('list_num', models.IntegerField(default=0)),
                ('check_item', models.ForeignKey(to='home_application.CheckItem')),
                ('report_detail', models.ForeignKey(to='home_application.CheckReportDetail')),
            ],
        ),
        migrations.CreateModel(
            name='Logs',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('operated_type', models.CharField(max_length=50)),
                ('content', models.TextField()),
                ('when_created', models.CharField(max_length=30)),
                ('operator', models.CharField(max_length=50)),
            ],
        ),
        migrations.CreateModel(
            name='Mailboxes',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('username', models.CharField(max_length=50)),
                ('mailbox', models.CharField(max_length=100)),
                ('when_created', models.CharField(max_length=30)),
            ],
        ),
        migrations.CreateModel(
            name='Settings',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('key', models.CharField(max_length=50)),
                ('value', models.TextField()),
                ('description', models.CharField(max_length=100, null=True)),
            ],
        ),
    ]
