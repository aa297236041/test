# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('home_application', '0005_auto_20190102_1536'),
    ]

    operations = [
        migrations.AddField(
            model_name='checkreport',
            name='summary_info',
            field=models.TextField(default=b'[]', verbose_name='\u5de1\u68c0\u62a5\u544a\u9519\u8bef\u6c47\u603b'),
        ),
    ]
