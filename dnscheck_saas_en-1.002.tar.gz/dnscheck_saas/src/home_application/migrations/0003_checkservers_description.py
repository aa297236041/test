# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('home_application', '0002_initial_check_item'),
    ]

    operations = [
        migrations.AddField(
            model_name='checkservers',
            name='description',
            field=models.TextField(default=b'', null=True),
        ),
    ]
