controllers.controller('error_summary', ["$scope", "reportService", "loading", "confirmModal", "msgModal", "$modal", "$stateParams", "$timeout", "$compile", function ($scope, reportService, loading, confirmModal, msgModal, $modal, $stateParams, $timeout, $compile) {
    $scope.rp_data = {
        name: '',
        when_created: '',
        check_summary: ''
    };
    $scope.summary_data = [];
    $scope.isShow = false;
    // $scope.summary_data= [{'name': 0, 'item': [
    //         {'display': '123','type':'dict', 'value': {"a":123,"b":{'type':'dict','value':{'c':1,'d':2}}}, 'way': '>', 'compare': '12'},
    //         {'display': '2', 'value': [{'a':1,'b':{'type':'list','keys':[{'你妹':'a'}],'value':[{'a':1},{'a':2}]}}],'keys':[{'你大爷':'a'},{'狗蛋':'b'}], 'way': '>', 'compare': '123','type':'list'},
    //         {'display': '1323', 'value': {"a":123,"b":{'type':'list','value':[{'c':1,'d':2}],'keys':[{'啦啦':'c'},{'呵呵':'d'}]}},'type':'dict', 'way': '>', 'compare': '123'},
    //     ]}];

    $scope.search = function () {
        loading.open();
        reportService.get_error_summary({id: $stateParams.id}, {}, function (res) {
            loading.close();
            if (res.result) {
                $scope.rp_data = res.data;
                // $scope.mw_data = res.mw;
                $scope.summary_data = res.summary_data;
                loading.open();
                $scope.lazy_start(res.summary_data.length);
            } else {
                msgModal.open("error", "获取数据失败，请联系管理员！");
            }
        })
    };
    $scope.search();

    $scope.down_pdf = function () {
        confirmModal.open({
            text: '是否导出PDF？',
            confirmClick: function () {
                var tempForm = document.createElement("form");
                tempForm.id = "tempForm1";
                tempForm.method = "post";
                //url
                tempForm.action = "export_error_summary/?report_id=" + $stateParams.id ;
                tempForm.target = '导出报表';
                var hideInput = document.createElement("input");
                hideInput.type = "hidden";
                //传入参数名,相当于get请求中的content=
                hideInput.name = "content";
                //传入传入数据，只传递了一个参数内容，实际可传递多个。
                // hideInput.value = $(".report_server").html();
                hideInput.value = $(".report_server").html()+'<style>div.obj_body>h5{display:none!important;}.obj_body table.error_table{display:table!important;}</style>';
                tempForm.appendChild(hideInput);
                // tempForm.addEventListener("onsubmit", function () {
                //     openWindow('导出报表');
                // });
                document.body.appendChild(tempForm);
                tempForm.dispatchEvent(new Event("onsubmit"));//chrome
                //必须手动的触发，否则只能看到页面刷新而没有打开新窗口
                tempForm.submit();
                document.body.removeChild(tempForm);
            }
        });
    };
    $scope.lazy_start = function (all_length, index) {
        index = index || 0;
        if (index > all_length) {
            loading.close();
            return
        }
        var end_index = index + 20;
        var end_html = '<div ng-repeat="rp in summary_data.slice(' + index + ',' + end_index + ') track by $index" ng-init="open={op:false}">' +
            '<div class="obj_title"><h5 ng-click="open.op=!open.op" style="cursor: pointer">{{ rp.name }}' +
            '<i class="fa fa-angle-down" ng-if="open.op"></i><i class="fa fa-angle-up" ng-if="!open.op"></i>' +
            '</h5></div>' +
            '<div class="obj_body">' +
            '<h5 ng-show="!open.op" ng-click="open.op=!open.op" style="cursor: pointer">巡检共发现<span class="error_item">{{ rp.item.length }}</span>项异常</h5>' +
            '<table class="table error_table" ng-show="open.op">' +
            '<tr class="tr_error"><th>巡检项</th><th>巡检值</th><th>关系</th><th>推荐值</th></tr>' +
            '<tr ng-repeat="item in rp.item">' +
            '<td ng-bind="item.display" title="{{ item.display }}"></td>' +
            '<td ng-if="item.type" cwhtml="item"></td>' +
            '<td ng-if="!item.type" ng-bind="item.value" title="{{ item.value }}"></td>' +
            '<td ng-bind="item.way" title="{{ item.way }}"></td>' +
            '<td ng-bind="item.compare" title="{{ item.compare }}"></td>' +
            '</tr>' +
            '</table>' +
            '</div>' +
            '</div>';
        var ele = $compile(end_html)($scope);
        if(all_length==0){
            ele='<span class="success_item" style="font-size: 2em">本次巡检未发现异常！</span>'
        }
        if(index==0){
            angular.element('.report_bottom').html(ele);
        }else {
            angular.element('.report_bottom').append(ele);
        }

        $timeout(function () {
            $scope.lazy_start(all_length, end_index)
        }, 100)
    };
}]);