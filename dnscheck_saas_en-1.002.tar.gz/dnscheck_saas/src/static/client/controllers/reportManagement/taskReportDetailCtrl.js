controllers.controller("taskReportDetailCtrl", ["$scope", "reportService", "loading", "errorModal", function ($scope, reportService, loading, errorModal) {
    var reportId = window.location.href.split("=")[1];
    $scope.serverList = [];

    $scope.reportObj = {
        id: ""
    };

    $scope.selectServer = {
        id: ""
    };

    $scope.is_show_title = true;

    $scope.openTitle = function () {
        $scope.is_show_title = !$scope.is_show_title;
    };

    $scope.titleIndex = 1;

    $scope.contentTitles = [
        {id: 1, name: "DNS信息", title: 'config'},
        {id: 2, name: "状态信息", title: 'status'},
        {id: 3, name: "事件日志", title: 'event'}
    ];
    $scope.task_report = {when_created: ""};

    reportService.get_check_server({report_id: reportId}, {}, function (res) {
        if (res.result) {
            $scope.serverList = res.data;
            $scope.selectServer.id = res.data[0].id;
            $scope.task_report.when_created = res.when_created;
            $scope.reportObj = $scope.serverList[0];
            if ($scope.reportObj.is_success) {
                $scope.initConfig();
            }
        }
    });

    $scope.initFun = function () {
        if ($scope.titleIndex == 1) {
            $scope.initConfig();
        }
        else if ($scope.titleIndex == 2) {
            $scope.initStatus();
        }
        else {
            $scope.initEvent();
        }
    };

    $scope.changeServer = function () {
        for (var i = 0; i < $scope.serverList.length; i++) {
            if ($scope.serverList[i].id == $scope.selectServer.id) {
                $scope.reportObj = $scope.serverList[i];
                break;
            }
        }
        $scope.initFun();
    };


    $scope.changeTitle = function (i) {
        $scope.titleIndex = i.id;
        $scope.initFun();
    };


    $scope.initConfig = function () {
        if (!$scope.reportObj.server) {
            loading.open();
            reportService.get_dns_server({
                server_id: $scope.reportObj.id
            }, {}, function (res) {
                loading.close();
                if (res.result) {
                    $scope.reportObj.server = res.server;
                    $scope.reportObj.pzones = res.pzones;
                    $scope.reportObj.rzones = res.rzones;
                    $scope.reportObj.fzones = res.fzones;
                }
                else {
                    errorModal.open(res.data);
                }
            });
        }
    };
    $scope.initStatus = function () {
        if (!$scope.reportObj.clusterList) {
            loading.open();
            reportService.get_status_info({
                server_id: $scope.reportObj.id
            }, {}, function (res) {
                loading.close();
                if (res.result) {
                    $scope.reportObj.service = res.service;
                    $scope.reportObj.port = res.port;
                    $scope.reportObj.system = res.system;
                    $scope.reportObj.disks = res.disks;
                    $scope.reportObj.services = res.services;
                }
                else {
                    errorModal.open(res.data);
                }
            })
        }
    };
    $scope.initEvent = function () {
        if (!$scope.reportObj.sysLogs) {
            loading.open();
            reportService.get_check_logs({
                server_id: $scope.reportObj.id
            }, {}, function (res) {
                loading.close();
                if (res.result) {
                    $scope.reportObj.sysLogs = res.sys_logs;
                    $scope.reportObj.appLogs = res.app_logs;
                    $scope.reportObj.dnsLogs = res.dns_logs;
                }
                else {
                    errorModal.open(res.data);
                }
            })
        }
    };
}]);