controllers.controller("selectServersCtrl", ["$scope", "sysService", "loading", "$modalInstance", "errorModal", function ($scope, sysService, loading, $modalInstance, errorModal) {
    $scope.filterObj = {
        name: "",
        ip_address: ""
    };

    $scope.serverList = [];
    $scope.search_ip = function () {
        sysService.search_vc_list({}, $scope.filterObj, function (res) {
            if (res.result) {
                $scope.serverList = res.data;
            }
            else {
                errorModal.open(res.data);
            }
        })
    }
    $scope.search_ip();
}]);