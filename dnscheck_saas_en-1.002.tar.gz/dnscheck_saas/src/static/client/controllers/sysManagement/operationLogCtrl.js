controllers.controller('operationLogCtrl', ["$scope", "errorModal", "sysService", "$filter", "$modal", function ($scope, errorModal, sysService, $filter, $modal) {
    var dateStart = new Date();
    var dateEnd = new Date();
    $scope.DateStart = dateStart.setDate(dateStart.getDate() - 29);
    $scope.DateEnd = dateEnd.setDate(dateEnd.getDate() + 1);

    $scope.recordList = [];
    $scope.Pagingdata = [];
    $scope.totalSerItems = 0;

    $scope.pagingOptions = {
        pageSizes: [10, 50, 100],
        pageSize: "10",
        currentPage: 1
    };

    $scope.filter = {
        operator: "",
        operateType: "",
        whenStart: $filter('date')($scope.DateStart, 'yyyy-MM-dd'),
        whenEnd: $filter('date')($scope.DateEnd, 'yyyy-MM-dd')
    };

    $scope.SearchObj = function () {
        sysService.search_log({}, $scope.filter, function (res) {
            $scope.recordList = res.data;
            $scope.pagingOptions.currentPage = 1;
            $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage);
        })
    };
    $scope.SearchObj();

    $scope.getPagedDataAsync = function (pageSize, page) {
        $scope.setPagingData($scope.recordList ? $scope.recordList : [], pageSize, page);
    };
    $scope.setPagingData = function (data, pageSize, page) {
        $scope.Pagingdata = data.slice((page - 1) * pageSize, page * pageSize);
        $scope.totalSerItems = data.length;
        if (!$scope.$$phase) {
            $scope.$apply();
        }
    };

    $scope.$watch('pagingOptions', function (newVal, oldVal) {
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage);
    }, true);

    $scope.gridoption = {
        data: "Pagingdata",
        enablePaging: true,
        showFooter: true,
        pagingOptions: $scope.pagingOptions,
        totalServerItems: 'totalSerItems',
        columnDefs: [
            {field: 'operator', displayName: '操作人', width: 80,},
            {field: 'operate_obj', displayName: '操作对象', width: 150},
            {field: 'operate_type', displayName: '操作类型', width: 150},
            {field: 'operate_time', displayName: '操作时间', width: 200},
            {field: 'content', displayName: '操作详情'},
            {
                displayName: '操作', width: 180,
                cellTemplate: '<div ng-if="row.entity.operated_detail.length != 0" style="width:100%;padding-top:5px;text-align: center">' +
                    '<span class="label label-btn label-sm label-primary" ' +
                    'ng-click="openDetail(row.entity)">详情</span>' +
                    '</div>'
            },
        ]
    };

    $scope.openDetail = function (rowEntity) {
        var modalInstance = $modal.open({
            templateUrl: static_url + 'client/views/sysManagement/logDetail.html',
            windowClass: 'logDialog',
            controller: 'logDetail',
            backdrop: 'static',
            resolve: {
                objectItem: function () {
                    return angular.copy(rowEntity);
                }
            }
        });
    };
}]);
