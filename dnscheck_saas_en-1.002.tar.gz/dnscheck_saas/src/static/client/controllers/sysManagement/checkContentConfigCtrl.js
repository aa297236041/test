controllers.controller("checkContentConfigCtrl",["$scope","sysService","loading","$modal","errorModal","msgModal","confirmModal",function ($scope,sysService,loading,$modal,errorModal,msgModal,confirmModal) {

}]);