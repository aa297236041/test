controllers.controller("dnsServerAddCtrl", ["$scope", "$modalInstance", "errorModal", "loading", "sysService", function ($scope, $modalInstance, errorModal, loading, sysService) {
    $scope.title = "新增DNS服务器";
    $scope.cancel = function () {
        $modalInstance.dismiss("cancel");
    };
    $scope.args = {
        app_name: "",
        ip_address: "",
        app_id: "",
        description: ''
    };
    $scope.app_list = [];
    $scope.searchBusiness = function () {
        loading.open("读取中", ".addDNS");
        sysService.get_app_list({}, {}, function (res) {
            loading.close(".addDNS");
            $scope.app_list = res.data;
        })
    };
    $scope.searchBusiness();

    $scope.ipList = [];

    $scope.search_ip = function () {
        loading.open();
        sysService.search_ip_list({
            app_id: $scope.args.app_id
        }, {}, function (res) {
            loading.close();
            if (res.result) {
                $scope.ipList = res.data;
            }
            else {
                errorModal.open(res.data);
            }
        });
    };

    $scope.selectOptions = {
        data: "ipList",
        multiple: true,
        modelData: "args.ip_address"
    };

    $scope.confirm = function () {
        var errors = validateObj();
        if (errors.length > 0) {
            errorModal.open(errors);
            return;
        }
        for (var i = 0; i < $scope.app_list.length; i++) {
            if ($scope.app_list[i].id == $scope.args.app_id) {
                $scope.args.app_name = $scope.app_list[i].text;
                break;
            }
        }
        loading.open("", ".addDNS");
        sysService.create_dns({}, $scope.args, function (res) {
            loading.close(".addDNS");
            if (res.result) {
                $modalInstance.close();
            }
            else {
                errorModal.open(res.data);
            }
        })
    };

    var validateObj = function () {
        var errors = [];
        if ($scope.args.app_id == "") {
            errors.push("DNS业务未选择！");
        }
        if ($scope.args.ip_address == "") {
            errors.push("服务器未选择！");
        }
        return errors;
    }
}]);