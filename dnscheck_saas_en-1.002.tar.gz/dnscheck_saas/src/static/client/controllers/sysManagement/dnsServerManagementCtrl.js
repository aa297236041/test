controllers.controller("dnsServerManagementCtrl", ["$scope", "sysService", "loading", "$modal", "errorModal", "msgModal", "confirmModal", function ($scope, sysService, loading, $modal, errorModal, msgModal, confirmModal) {
    $scope.filterObj = {
        name: "",
        ip_address: ""
    };
    $scope.dnsList = [];
    $scope.Pagingdata = [];
    $scope.totalSerItems = 0;
    $scope.pagingOptions = {
        pageSizes: [10, 50, 100],
        pageSize: "10",
        currentPage: 1
    };

    $scope.searchObj = function () {
        sysService.search_dns_list({}, $scope.filterObj, function (res) {
            if (res.result) {
                $scope.dnsList = res.data;
                $scope.pagingOptions.currentPage = 1;
                $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage);
            }
            else {
                errorModal.open(res.data);
            }
        })
    };
    $scope.getPagedDataAsync = function (pageSize, page) {
        $scope.setPagingData($scope.dnsList ? $scope.dnsList : [], pageSize, page);
    };
    $scope.setPagingData = function (data, pageSize, page) {
        $scope.Pagingdata = data.slice((page - 1) * pageSize, page * pageSize);
        $scope.totalSerItems = data.length;
        if (!$scope.$$phase) {
            $scope.$apply();
        }
    };

    $scope.$watch('pagingOptions', function (newVal, oldVal) {
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage);
    }, true);
    $scope.searchObj();

    $scope.gridOption = {
        data: "Pagingdata",
        enablePaging: true,
        showFooter: true,
        pagingOptions: $scope.pagingOptions,
        totalServerItems: 'totalSerItems',
        columnDefs: [
            {field: 'ip_address', displayName: 'DNS服务器IP地址', width: 200},
            {field: 'app_name', displayName: '业务系统名称', width: 200},
            {field: 'description', displayName: '描述'},
            {
                displayName: '操作', width: 150,
                cellTemplate: '<div style="width:100%;padding-top:5px;text-align: center;">' +
                // '<span class="label label-sm label-info label-btn" ng-click="modifyServer(row.entity)">修改</span>&emsp;' +
                '<span class="label label-sm label-danger label-btn button-radius" ng-click="deleteServer(row)">删除</span>' +
                '</div>'
            }
        ]
    };

    $scope.addDNS = function () {
        var modalInstance = $modal.open({
            templateUrl: static_url + 'client/views/sysManagement/dnsServerAdd.html',
            windowClass: 'dialogForm',
            controller: 'dnsServerAddCtrl',
            backdrop: 'static'
        });
        modalInstance.result.then(function () {
            $scope.searchObj();
        })
    };

    $scope.modifyServer = function (rowEntity) {
        var modalInstance = $modal.open({
            templateUrl: static_url + 'client/views/sysManagement/dnsServerAdd.html',
            windowClass: 'dialog_custom',
            controller: 'dnsServerModifyCtrl',
            backdrop: 'static',
            resolve: {
                objectItem: function () {
                    return rowEntity
                }
            }
        });
        modalInstance.result.then(function (res) {
            rowEntity.name = res.name;
            rowEntity.dnsenter_ip = res.dnsenter_ip;
            rowEntity.dnsenter_user = res.dnsenter_user;
            rowEntity.dnsenter_pwd = res.dnsenter_pwd;
        })
    };

    $scope.deleteServer = function (row) {
        confirmModal.open({
            text: "请确认是否删除该DNS服务器",
            confirmClick: function () {
                loading.open();
                sysService.delete_dns({}, row.entity, function (res) {
                    loading.close();
                    if (res.result) {
                        $scope.dnsList.splice(row.rowIndex, 1);
                        $scope.pagingOptions.currentPage = 1;
                        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage);
                    }
                    else {
                        errorModal.open(res.data);
                    }
                })
            }
        })
    };
}]);