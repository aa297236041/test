controllers.controller("logDetail", function ($scope, $modalInstance, objectItem) {
    $scope.logDetail = objectItem.operated_detail;
    $scope.logType = objectItem.operated_type;

    $scope.cancel = function () {
        $modalInstance.dismiss("cancel");
    }
});