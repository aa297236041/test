controllers.controller("dnsServerModifyCtrl", ["$scope", "objectItem", "$modalInstance", "errorModal", "loading", "sysService", function ($scope, objectItem, $modalInstance, errorModal, loading, sysService) {
    $scope.title = "修改DNS服务器";
    $scope.isModify = true;
    $scope.args = objectItem;
    var pwd = angular.copy($scope.args.dnsenter_pwd);
    $scope.args.isModifyPwd = false;

    $scope.modifyPwd = function () {
        $scope.args.isModifyPwd = true;
        $scope.args.dnsenter_pwd = "";
    };

    $scope.cancel = function () {
        if ($scope.args.isModifyPwd) {
            $scope.args.dnsenter_pwd = pwd;
        }
        $modalInstance.dismiss("cancel");
    };

    $scope.confirm = function () {
        var errors = validateObj();
        if (errors.length > 0) {
            errorModal.open(errors);
            return;
        }
        loading.open("", ".addDNS");
        sysService.modify_dns({}, $scope.args, function (res) {
            loading.close(".addDNS");
            if (res.result) {
                $modalInstance.close(res.data);
            }
            else {
                errorModal.open(res.data);
            }
        })
    };

    var validateObj = function () {
        var errors = [];
        if ($scope.args.name == "") {
            errors.push("DNS名称不能为空！");
        }
        if ($scope.args.dnsenter_ip == "" || !CWApp.isIP($scope.args.dnsenter_ip)) {
            errors.push("DNS服务器IP格式有误！");
        }
        if ($scope.args.dnsenter_user == "") {
            errors.push("DNS服务器帐号不能为空！");
        }
        if ($scope.args.dnsenter_pwd == "") {
            errors.push("DNS服务器登录密码不能为空！");
        }
        return errors;
    }
}]);