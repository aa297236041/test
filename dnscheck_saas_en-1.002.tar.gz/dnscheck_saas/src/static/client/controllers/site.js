controllers.controller("site", ["$scope", "sysService", function ($scope, sysService) {
    $scope.menuList = [
        {
            displayName: "首页", iconClass: "fa fa-home fa-lg", url: "#/home"
        },
        {
            displayName: "巡检管理", iconClass: "fa fa-fw fa-stethoscope",
            children: [
                {displayName: "DNS服务器管理", url: "#/dnsServerManagement"},
                {displayName: "巡检任务配置", url: "#/taskList"},
                {displayName: "历史巡检报告", url: "#/taskReport"}
            ]
        },
        {
            displayName: "系统管理", iconClass: "fa fa-cog fa-lg",
            children: [
                // {displayName: "巡检标准配置", url: "#/checkContentConfig"},
                {displayName: "系统设置", url: "#/changeLogo"},
                {displayName: "邮箱管理", url: "#/mailManagement"},
                {displayName: "操作日志", url: "#/operationLog"}
            ]
        }
    ];

    $scope.logo_img = site_url + "show_logo/";

    $scope.menuOption = {
        data: 'menuList',
        locationPlaceHolder: '#locationPlaceHolder',
        adaptBodyHeight: CWApp.HeaderHeight + CWApp.FooterHeight
    };

    sysService.update_url({
        app_path: app_path
    }, {}, function (res) {

    })

}]);