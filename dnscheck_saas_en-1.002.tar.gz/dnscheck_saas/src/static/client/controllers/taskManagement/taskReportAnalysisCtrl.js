controllers.controller("taskReportAnalysisCtrl", ["$scope", "historyService", "sysService", "loading", "errorModal", function ($scope, historyService, sysService, loading, errorModal) {
    $scope.selectItem = {
        id: ""
    };

    $scope.historyObj = {
        id: ""
    };

    $scope.contentTitles = [
        {id: 1, name: "配置差异对比", title: 'vc'},
        {id: 2, name: "群集资源使用", title: 'cluster'},
        {id: 3, name: "主机资源使用", title: 'esx_host'},
        {id: 4, name: "存储资源使用", title: 'ds'},
        {id: 5, name: "告警事件数量", title: 'error'},
        {id: 6, name: "虚拟机数量", title: 'vm'}
    ];

    $scope.is_show_all_hint = false;
    $scope.title_index = 1;
    $scope.is_show_title = false;
    $scope.is_show_one_hint = false;

    $scope.openTitle = function () {
        $scope.is_show_title = !$scope.is_show_title;
    };
    $scope.changeIndex = function (i) {
        if (i.title == "vc") {
            $scope.initVCenter();
        }
        else if (i.title == "cluster") {
            $scope.initCluster();
        }
        else if (i.title == "esx_host") {
            $scope.initESXHost();
        }
        else if (i.title == "ds") {
            $scope.initDS();
        }
        else if (i.title == "error") {
            $scope.initError();
        }
        else {
            $scope.initVM();
        }
        $scope.title_index = i.id;
    };

    $scope.changeServer = function () {
        for (var i = 0; i < $scope.vcenterList.length; i++) {
            if ($scope.vcenterList[i].id = $scope.selectItem.id) {
                $scope.historyObj = $scope.vcenterList[i];
                $scope.is_show_title = false;
                $scope.is_show_one_hint = false;
                break;
            }
        }
    };

    $scope.vcenterList = [];

    $scope.get_vcenter_list = function () {
        sysService.get_vcenter_list({}, {}, function (res) {
            $scope.is_show_all_hint = res.compare_error;
            if (res.result) {
                $scope.vcenterList = res.data;
                $scope.selectItem.id = res.data[0].id;
                $scope.historyObj = $scope.vcenterList[0];
                $scope.initVCenter();
            }
            else {
                if (res.data)
                    errorModal.open(res.data);
            }
        })
    };
    $scope.get_vcenter_list();

    $scope.checkItemList = [];
    $scope.clusterList = [];
    $scope.hostList = [];
    $scope.dsList = [];
    $scope.eventList = [];
    $scope.vmList = [];
    $scope.usedHighList = [];
    $scope.is_show_hint = true;

    $scope.clusterCpuReports = {
        data: "historyObj.cluster.cpu_chart",
        chart: {type: 'line'},
        title: {text: '群集CPU使用变化', enabled: true},
        xAxis: {
            categories: []
        },
        //提示框位置和显示内容
        tooltip: {
            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:f}</b></td></tr>',
            headerFormat: ""
        }
    };

    $scope.clusterMemReports = {
        data: "historyObj.cluster.mem_chart",
        chart: {type: 'line'},
        title: {text: '群集内存使用变化', enabled: true},
        xAxis: {
            categories: []
        },
        //提示框位置和显示内容
        tooltip: {
            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:f}</b></td></tr>',
            headerFormat: ""
        }
    };

    $scope.hostCpuReports = {
        data: "historyObj.host.cpu_chart",
        chart: {type: 'line'},
        title: {text: '主机CPU使用变化', enabled: true},
        xAxis: {
            categories: []
        },
        //提示框位置和显示内容
        tooltip: {
            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:f}</b></td></tr>',
            headerFormat: ""
        }
    };

    $scope.hostMemReports = {
        data: "historyObj.host.mem_chart",
        chart: {type: 'line'},
        title: {text: '主机内存使用变化', enabled: true},
        xAxis: {
            categories: []
        },
        //提示框位置和显示内容
        tooltip: {
            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:f}</b></td></tr>',
            headerFormat: ""
        }
    };

    $scope.dsReports = {
        data: "historyObj.ds",
        chart: {type: 'line'},
        title: {text: '存储资源使用变化', enabled: true},
        xAxis: {
            categories: []
        },
        //提示框位置和显示内容
        tooltip: {
            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:f}</b></td></tr>',
            headerFormat: ""
        }
    };

    $scope.errorReports = {
        data: "historyObj.error",
        chart: {type: 'line'},
        title: {text: '告警事件数变化', enabled: true},
        xAxis: {
            categories: []
        },
        //提示框位置和显示内容
        tooltip: {
            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:f}</b></td></tr>',
            headerFormat: ""
        }
    };

    $scope.vmReports = {
        data: "historyObj.vm",
        chart: {type: 'line'},
        title: {text: '虚拟机数量变化', enabled: true},
        xAxis: {
            categories: []
        },

        //提示框位置和显示内容
        tooltip: {
            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:f}</b></td></tr>',
            headerFormat: ""
        }
    };

    $scope.vmResourceReports = {
        data: "historyObj.vmResource",
        chart: {type: 'bar'},
        title: {text: '虚拟机资源使用率', enabled: true},
        //提示框位置和显示内容
        tooltip: {
            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:f}</b></td></tr>',
            headerFormat: ""
        }
    };
    $scope.initVCenter = function () {
        if ($scope.historyObj.vc)
            return;
        loading.open();
        historyService.get_venter_compare({
            vcenter_ip: $scope.historyObj.id
        }, {}, function (res) {
            loading.close();
            $scope.is_show_one_hint = res.compare_error;
            if (res.result) {
                $scope.historyObj.vc = res.data;
                $scope.historyObj.cluster_list = res.cluster_list;
                $scope.historyObj.ds_list = res.ds_list;
                $scope.historyObj.dvs_list = res.dvs_list;
                if (res.is_has_different) {
                    $scope.is_show_hint = false;
                }
                else {
                    $scope.is_show_hint = true;
                }
            }
            else {
                if (res.data)
                    errorModal.open(res.data);
            }
        })
    };

    $scope.initCluster = function () {
        if ($scope.historyObj.cluster)
            return;
        loading.open();
        historyService.get_cluster_compare({
            vcenter_ip: $scope.historyObj.id
        }, {}, function (res) {
            loading.close();
            $scope.is_show_one_hint = res.compare_error;
            if (res.result) {
                $scope.historyObj.cluster = res.data;
                $scope.clusterCpuReports.xAxis.categories = res.categories;
                $scope.clusterMemReports.xAxis.categories = res.categories;
            }
            else {
                if (res.data)
                    errorModal.open(res.data);
            }
        })
    };
    $scope.initESXHost = function () {
        if ($scope.historyObj.host)
            return;
        loading.open();
        historyService.get_host_compare({
            vcenter_ip: $scope.historyObj.id
        }, {}, function (res) {
            loading.close();
            $scope.is_show_one_hint = res.compare_error;
            if (res.result) {
                $scope.historyObj.host = res.data;
                $scope.hostCpuReports.xAxis.categories = res.categories;
                $scope.hostMemReports.xAxis.categories = res.categories;
            }
            else {
                if (res.data)
                    errorModal.open(res.data);
            }
        })
    };
    $scope.initDS = function () {
        if ($scope.historyObj.ds)
            return;
        loading.open();
        historyService.get_ds_compare({
            vcenter_ip: $scope.historyObj.id
        }, {}, function (res) {
            loading.close();
            $scope.is_show_one_hint = res.compare_error;
            if (res.result) {
                $scope.historyObj.ds = res.data;
                $scope.dsReports.xAxis.categories = res.categories;
            }
            else {
                if (res.data)
                    errorModal.open(res.data);
            }
        })
    };

    $scope.initError = function () {
        if ($scope.historyObj.error)
            return;
        loading.open();
        historyService.get_alarms_compare({
            vcenter_ip: $scope.historyObj.id
        }, {}, function (res) {
            loading.close();
            $scope.is_show_one_hint = res.compare_error;
            if (res.result) {
                $scope.historyObj.error = res.data;
                $scope.errorReports.xAxis.categories = res.categories;
            }
            else {
                if (res.data)
                    errorModal.open(res.data);
            }
        })
    };

    $scope.initVM = function () {
        if ($scope.historyObj.vm)
            return;
        loading.open();
        historyService.get_vm_compare({
            vcenter_ip: $scope.historyObj.id
        }, {}, function (res) {
            loading.close();
            $scope.is_show_one_hint = res.compare_error;
            if (res.result) {
                $scope.historyObj.vm = res.data;
                // $scope.historyObj.vmResource = res.vm_resource;
                $scope.vmReports.xAxis.categories = res.categories;
            }
            else {
                if (res.data)
                    errorModal.open(res.data);
            }
        })
    };

}]);