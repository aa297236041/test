controllers.controller("checkContentListCtrl", ["$scope", "taskService", "msgModal", "loading", "errorModal", function ($scope, taskService, msgModal, loading, errorModal) {
    $scope.contentList = [];
    $scope.old_content = [];
    $scope.init = function () {
        taskService.search_check_content({}, {}, function (res) {
            if (res.result) {
                $scope.contentList = res.data;
                $scope.old_content = res.data;
            }
            else {
                errorModal.open(res.data);
            }
        })
    };
    $scope.init();
    $scope.isModify = false;

    $scope.modify = function () {
        $scope.isModify = true;
    };

    $scope.cancel = function () {
        $scope.contentList = angular.copy($scope.old_content);
        $scope.isModify = false;
    };
    $scope.confirm = function () {
        loading.open();
        taskService.set_check_content({}, $scope.contentList, function (res) {
            loading.close();
            if (res.result) {
                msgModal.open("info", "修改成功");
                $scope.isModify = false;
            }
            else {
                errorModal.open(res.data);
            }
        })
    };
}]);