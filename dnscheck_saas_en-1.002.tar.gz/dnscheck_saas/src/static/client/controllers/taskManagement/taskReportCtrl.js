controllers.controller("taskReportCtrl", ["$scope", "$filter", "taskService", "reportService", "loading", "msgModal", "errorModal","confirmModal", function ($scope, $filter, taskService, reportService, loading, msgModal, errorModal,confirmModal) {
    var dateStart = new Date();
    var dateEnd = new Date();
    $scope.DateStart = dateStart.setDate(dateStart.getDate() - 30);
    $scope.DateEnd = dateEnd.setDate(dateEnd.getDate());

    $scope.is_auto = false;

    $scope.filterObj = {
        start_time: $filter('date')($scope.DateStart, 'yyyy-MM-dd'),
        end_time: $filter('date')($scope.DateEnd, 'yyyy-MM-dd')
    };

    $scope.PagingData = [];
    $scope.totalSerItems = 0;

    $scope.pagingOptions = {
        pageSizes: [10, 50, 100],
        pageSize: "10",
        currentPage: 1
    };

    $scope.runTask = function () {
        loading.open();
        taskService.run_task({}, {}, function (res) {
            loading.close();
            if (res.result) {
                msgModal.open("success", "启动成功");
                $scope.is_auto = true;
                setTimeout($scope.searchList, 1000);
            }
            else {
                errorModal.open(res.data);
            }
        })
    };

    $scope.searchList = function () {
        reportService.search_report({}, $scope.filterObj, function (res) {
            if (res.result) {
                $scope.reportList = res.data;
                $scope.pagingOptions.currentPage = 1;
                $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage);
                $scope.is_auto = res.data.length == 0 ? false : res.data[0].status != "COMPLETE";
            }
            else {
                msgModal.open("error", res.data[0]);
            }
            if ($scope.is_auto)
                setTimeout($scope.searchList, 5000);
        })
    };
    $scope.getPagedDataAsync = function (pageSize, page) {
        $scope.setPagingData($scope.reportList ? $scope.reportList : [], pageSize, page);
    };

    $scope.setPagingData = function (data, pageSize, page) {
        $scope.PagingData = data.slice((page - 1) * pageSize, page * pageSize);
        $scope.totalSerItems = data.length;
        if (!$scope.$$phase) {
            $scope.$apply();
        }
    };

    $scope.$watch('pagingOptions', function (newVal, oldVal) {
        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage);
    }, true);
    $scope.searchList();
    $scope.gridOption = {
        data: "PagingData",
        enablePaging: true,
        showFooter: true,
        pagingOptions: $scope.pagingOptions,
        totalServerItems: 'totalSerItems',
        columnDefs: [
            {field: "when_created", displayName: "执行时间", width: 200},
            {field: "report_info", displayName: "任务概览"},
            {
                displayName: "任务进度", width: 150,
                cellTemplate: '<div class="progress progress-striped active" style="height:29px;margin-bottom:1px"><div class="progress-bar progress-bar-success" style="width: {{ row.entity.schedule }};line-height: 29px">{{ row.entity.schedule }}</div></div>'
            },
            {
                displayName: "状态", width: 120,
                cellTemplate: '<div style="width:100%;padding-top:5px;text-align: center">' +
                '<span  ng-if="row.entity.status == \'RUNNING\'">' +
                '<i  class="fa fa-spinner fa-pulse"></i>\
                进行中</span>\
                <span  ng-if="row.entity.status == \'COMPLETE\'" >\
                 <i class="fa fa-check color_green"></i>\
                 完成</span>' +
                '</div>'
            },
            {
                displayName: "操作", width: 180,
                cellTemplate: '<div style="width:100%;padding-top:5px;text-align: center">' +
                '<span ng-if="row.entity.status == \'COMPLETE\'" ng-click="openDetail(row.entity)" class="label label-sm label-info label-btn button-radius">详情</span>' +
                '<span ng-if="row.entity.status == \'RUNNING\'" style="box-shadow:none;opacity:0.65" class="label label-sm label-info button-radius">详情</span>' +
                '<span ng-if="row.entity.status == \'COMPLETE\'" style="margin: 0 5px" ui-sref="error_summary({id:row.entity.id})" class="label label-sm label-warning label-btn button-radius">错误汇总</span>' +
                '<span ng-if="row.entity.status == \'RUNNING\'" style="margin: 0 5px;box-shadow:none;opacity:0.65" class="label label-sm label-warning label-btn button-radius" disabled="disabled">错误汇总</span>' +
                '<span ng-if="row.entity.status == \'COMPLETE\'" ng-click="deleteReport(row)" class="label label-sm label-danger label-btn button-radius">删除</span>' +
                '<span ng-if="row.entity.status == \'RUNNING\'" ng-click="deleteReport(row)"  class="label label-sm label-danger label-btn button-radius">删除</span>' +
                '</div>'
            }
        ]
    };

    $scope.openDetail = function (rowEntity) {
        window.open(site_url + "check_report/#/serverDetail?report_id=" + rowEntity.id);
    }

    // 删除报告
    $scope.deleteReport = function (row) {
        var id = row.entity.id;
        confirmModal.open({
            text: "确认删除该巡检报告吗？",
            confirmClick: function () {
                loading.open();
                reportService.delete_report_obj({id: id}, {}, function (res) {
                    loading.close();
                    if (res.result) {
                        $scope.reportList.splice(row.rowIndex, 1);
                        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage);
                        msgModal.open("success", "删除成功");
                    }
                    else {
                        errorModal.open(res.data);
                    }
                })
            }
        })
    };


}]);