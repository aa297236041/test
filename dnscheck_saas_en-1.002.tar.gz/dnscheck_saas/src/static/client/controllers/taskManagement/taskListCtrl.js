controllers.controller("taskListCtrl", ["$scope", "taskService", "loading", "errorModal", "msgModal", "$filter", function ($scope, taskService, loading, errorModal, msgModal, $filter) {
    $scope.isFirst = false;
    $scope.oldTaskObj = {};

    $scope.taskObj = {
        name: "",
        isCreated: true,
        first_run_time: "",
        time_interval: "",
        script_account: "",
        keeps: ""
    };

    $scope.searchList = function () {
        loading.open();
        taskService.search_task({}, $scope.filterObj, function (res) {
            loading.close();
            if (res.result) {
                $scope.taskObj = res.data;
                $scope.oldTaskObj = angular.copy(res.data);
                if ($scope.taskObj.id) {
                    $scope.taskObj.isCreated = true;
                    $scope.isFirst = false;
                }
                else {
                    $scope.taskObj.isCreated = false;
                    $scope.isFirst = true;
                }
            }
            else {
                errorModal.open(res.data);
            }
        })
    };

    $scope.searchList();

    $scope.confirm = function () {
        var errors = validate();
        if (errors.length > 0) {
            errorModal.open(errors);
            return;
        }
        loading.open();
        taskService.set_task({}, $scope.taskObj, function (res) {
            loading.close();
            if (res.result) {
                msgModal.open("success", "设置成功", "");
                $scope.searchList();
            }
        })
    }

    var validate = function () {
        var errors = [];
        if ($scope.taskObj.first_run_time == "") {
            errors.push("开始执行时间未选择！");
        }
        else {
            var error_d = CWApp.ValidateDate($filter, $scope.taskObj.first_run_time);
            if (error_d != "") {
                errors.push(error_d);
            }
        }
        if ($scope.taskObj.time_interval == "") {
            errors.push("时间间隔不能为空！");
        }
        else if (!CWApp.isNum($scope.taskObj.time_interval) || $scope.taskObj.time_interval == "0") {
            errors.push("时间间隔只允许为正整数！")
        }
        if (!CWApp.isNum($scope.taskObj.keeps)) {
            errors.push("历史保留份数只允许为大于或等于0的整数！")
        }
        return errors;
    };
    $scope.modifyItem = function () {
        $scope.taskObj.isCreated = false;
    };
    $scope.cancel = function () {
        $scope.taskObj = angular.copy($scope.oldTaskObj);
        $scope.taskObj.isCreated = true;
    }
}]);