﻿services = angular.module('webApiService', ['ngResource', 'utilServices']);

//生产代码
var POST = "POST";
var GET = "GET";

//测试代码
//var sourceRoute = "./Client/MockData";
//var fileType = ".html";
//var POST = "GET";
//var GET = "GET";
services.factory('sysService', ['$resource', function ($resource) {
    return $resource(site_url + ':actionName/', {},
        {
            get_count_obj: {method: POST, params: {actionName: 'get_count_obj'}, isArray: false},
            update_url: {method: POST, params: {actionName: 'update_url'}, isArray: false},
            get_app_list: {method: POST, params: {actionName: 'get_app_list'}, isArray: false},
            search_ip_list: {method: POST, params: {actionName: 'search_ip_list'}, isArray: false},

            search_log: {method: POST, params: {actionName: 'search_log'}, isArray: false},

            search_dns_list: {method: POST, params: {actionName: 'search_dns_list'}, isArray: false},
            create_dns: {method: POST, params: {actionName: 'create_dns'}, isArray: false},
            modify_dns: {method: POST, params: {actionName: 'modify_dns'}, isArray: false},
            delete_dns: {method: POST, params: {actionName: 'delete_dns'}, isArray: false},

            add_mail: {method: POST, params: {actionName: 'add_mail'}, isArray: false},
            modify_mail: {method: POST, params: {actionName: 'modify_mail'}, isArray: false},
            delete_mail: {method: POST, params: {actionName: 'delete_mail'}, isArray: false},
            search_mail: {method: POST, params: {actionName: 'search_mail'}, isArray: false},
            get_all_mails: {method: POST, params: {actionName: 'get_all_mails'}, isArray: false},
            set_default_img: {method: POST, params: {actionName: 'set_default_img'}, isArray: false},

        });
}])
.factory('taskService', ['$resource', function ($resource) {
    return $resource(site_url + ':actionName/', {}, {
        search_task: {method: POST, params: {actionName: 'search_task'}, isArray: false},
        set_task: {method: POST, params: {actionName: 'set_task'}, isArray: false},
        run_task: {method: POST, params: {actionName: 'run_task'}, isArray: false},
        set_check_content: {method: POST, params: {actionName: 'set_check_content'}, isArray: false},
        search_check_content: {method: POST, params: {actionName: 'search_check_content'}, isArray: false},
    });
}])
.factory('reportService', ['$resource', function ($resource) {
    return $resource(site_url + ':actionName/', {}, {
        search_report: {method: POST, params: {actionName: 'search_report'}, isArray: false},
        get_check_server: {method: POST, params: {actionName: 'get_check_server'}, isArray: false},
        get_dns_server: {method: POST, params: {actionName: 'get_dns_server'}, isArray: false},
        get_status_info: {method: POST, params: {actionName: 'get_status_info'}, isArray: false},
        get_check_logs: {method: POST, params: {actionName: 'get_check_logs'}, isArray: false},
        get_error_summary: {method: POST, params: {actionName: 'get_error_summary'}, isArray: false},
        delete_report_obj: {method: POST, params: {actionName: 'delete_report_obj'}, isArray: false},
    });
}])

;//这是结束符，请勿删除